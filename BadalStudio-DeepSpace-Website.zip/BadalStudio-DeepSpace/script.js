const intro = document.getElementById("intro");
const introVideo = document.getElementById("introVideo");
const skipIntro = document.getElementById("skipIntro");
const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
let introClosed = false;

function enterSite() {
  if (introClosed) return;
  introClosed = true;
  document.body.classList.remove("intro-pending");
  document.body.classList.add("site-ready");
  if (intro) {
    intro.classList.add("is-leaving");
    window.setTimeout(() => intro.remove(), 1250);
  }
  try { sessionStorage.setItem("badalstudioIntroSeen", "yes"); } catch (e) {}
}

// Show the cinematic intro once per browser tab/session; keep the moving space scene behind the site.
let alreadySeen = false;
try { alreadySeen = sessionStorage.getItem("badalstudioIntroSeen") === "yes"; } catch (e) {}
if (reducedMotion || alreadySeen) {
  enterSite();
} else {
  if (introVideo) {
    introVideo.addEventListener("ended", enterSite, { once: true });
    // Fallback for browsers that do not fire "ended" reliably.
    window.setTimeout(enterSite, 6500);
    const playAttempt = introVideo.play();
    if (playAttempt && typeof playAttempt.catch === "function") playAttempt.catch(() => window.setTimeout(enterSite, 1200));
  } else {
    window.setTimeout(enterSite, 500);
  }
}
if (skipIntro) skipIntro.addEventListener("click", enterSite);

const menuToggle = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");
if (menuToggle && navLinks) {
  menuToggle.addEventListener("click", () => {
    const open = menuToggle.getAttribute("aria-expanded") === "true";
    menuToggle.setAttribute("aria-expanded", String(!open));
    navLinks.classList.toggle("open", !open);
    menuToggle.setAttribute("aria-label", open ? "Open navigation" : "Close navigation");
  });
  navLinks.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.setAttribute("aria-label", "Open navigation");
  }));
}

const revealItems = document.querySelectorAll(".reveal");
if ("IntersectionObserver" in window) {
  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: "0px 0px -30px 0px" });
  revealItems.forEach(item => observer.observe(item));
} else {
  revealItems.forEach(item => item.classList.add("is-visible"));
}

const year = document.getElementById("year");
if (year) year.textContent = new Date().getFullYear();

// Keep the page usable if the background video cannot load.
document.querySelectorAll(".space-video, .intro-video").forEach(video => {
  video.addEventListener("error", () => {
    if (video.classList.contains("intro-video")) enterSite();
  });
});
